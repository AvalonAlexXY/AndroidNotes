package com.zhy.autolayout.config;

/**
 * Created by zhy on 15/12/5.
 * 如果Activity设计稿是横屏，继承该接口即可
 */
public interface UseLandscape
{
}
