package com.benbun.mvpdemo.presenter;

import android.util.Log;
import android.view.View;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.benbun.mvpdemo.bean.VehicleBean;
import com.benbun.mvpdemo.view.VehicleHolderView;
import com.benbun.mvpdemo.webservice.VehicleApi;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;

/**
 * Created by kongweixian on 16/1/15.
 */
public class VehicleDetailPresenter extends BasePresenter {
    public static final String TAG = "VehicleDetailPresenter";
    // Presenter作为中间层，持有View, 操作数据(Model)
    private VehicleHolderView vehicleView;

    public VehicleDetailPresenter(RootPresenter rootPresenter, View parentView) {
        super(rootPresenter);
        vehicleView = new VehicleHolderView(parentView);
    }

    public void getVehicle(String token) {
        // 请求网络数据
        Log.i(TAG, "GET VEHICLE token: " + token);
        RequestCallBack<String> requestCallBack = new RequestCallBack<String>() {
            @Override
            public void onSuccess(ResponseInfo<String> responseInfo) {
                VehicleDetailPresenter.this.onSuccess(responseInfo.result);
            }

            @Override
            public void onFailure(HttpException error, String msg) {
                VehicleDetailPresenter.this.onFailure(msg);
                error.printStackTrace();
            }
        };
        VehicleApi.getDefaultVehicle(getContext(), token, requestCallBack);
    }

    // 网络请求成功
    public void onSuccess(String response) {
        try {
            JSONObject responseObj = JSON.parseObject(response);
            Log.i(TAG, "response:" + responseObj.getJSONObject("data"));
            VehicleBean vehicle = JSON.parseObject(responseObj.getJSONObject("data").toString(), VehicleBean.class);
            Log.i(TAG, "vehicle type " + vehicle.getType());
            vehicleView.updateData(vehicle);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 网络请求失败
    public void onFailure(String msg) {
        Log.i(TAG, "request failed msg: " + msg);
    }


}
