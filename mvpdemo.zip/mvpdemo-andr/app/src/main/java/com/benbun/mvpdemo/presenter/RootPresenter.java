package com.benbun.mvpdemo.presenter;

import android.os.Bundle;
import android.support.annotation.Nullable;

/**
 * Created by kongweixian on 16/1/14.
 */
public interface RootPresenter extends Presenter {

    public void showLoading();

    public void hideLoading();

    public void showError(String text);
}
