package com.benbun.mvpdemo.utils;

import android.content.Context;
import android.util.Log;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by kongweixian on 16/1/15.
 */
public class NetWorkUtils {
    public static final String TAG = "NetWorkUtils";
    private static class NetworkUtilsHolder {
        public static NetWorkUtils networkUtils = new NetWorkUtils();
    }

    public static NetWorkUtils getInstance() {
        return NetworkUtilsHolder.networkUtils;
    }

    private static class HttpUtilsHolder {
        public static HttpUtils httpUtils = new HttpUtils();
    }

    public static HttpUtils getHttpUtils(Context context) {
        HttpUtils httpUtils = HttpUtilsHolder.httpUtils;
        httpUtils.configSoTimeout(600000);
        httpUtils.configTimeout(200000);
        httpUtils.sHttpCache.setEnabled(HttpRequest.HttpMethod.GET, true);
        return httpUtils;
    }

    public HttpUtils getShortHttpUtils(Context context) {
        HttpUtils httpUtils = HttpUtilsHolder.httpUtils;
        httpUtils.configSoTimeout(20000);
        httpUtils.configTimeout(10000);
        return httpUtils;
    }

    private NetWorkUtils() {

    }


    /**
     * 请求json格式数据
     *
     * @param url
     * @param params          请求参数
     * @param requestCallBack
     * @param context
     */
    public void get(String url, Map<String, String> params, RequestCallBack<String> requestCallBack,
                    Context context) {
        StringBuilder sb = this.buildGetString(url, params);
        Log.i(TAG, sb.toString());
        this.get(sb.toString(), requestCallBack, context);
    }


    /**
     * 请求json格式数据
     *
     * @param url
     * @param requestCallBack
     * @param context
     */
    public void get(String url, RequestCallBack<String> requestCallBack,
                    Context context) {
        HttpUtils httpUtils = getHttpUtils(context);
        RequestParams requestParams = new RequestParams();
        requestParams.setContentType("application/json");
        httpUtils.send(HttpRequest.HttpMethod.GET, url, requestParams,
                requestCallBack);
    }

    public StringBuilder buildGetString(String path, Map<String, String> params) {
        StringBuilder sb = new StringBuilder(path);
        sb.append("?");

        for (Map.Entry<String, String> entry : params.entrySet()) {
            sb.append(entry.getKey()).append('=').append(entry.getValue()).append('&');
        }
        if (sb.length() > 1) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb;
    }

    /**
     * 提交form格式的表单,提交数据为java bean, 请求json格式的返回数据
     *
     * @param url
     * @param obj             java bean,每个属性应当实现toString方法
     * @param requestCallBack
     * @param context
     */
    public void postObject(String url, Object obj,
                           RequestCallBack requestCallBack, Context context) {
        Map<String, String> params = ReflectionUtils.getKeyValueMap(obj);
        this.postForm(url, params, requestCallBack, context);
    }


    /**
     * 提交form格式的表单，请求json格式的返回数据
     *
     * @param url
     * @param params
     * @param requestCallBack
     * @param context
     */
    public void postForm(String url, Map<String, String> params,
                         RequestCallBack requestCallBack, Context context) {
        HttpUtils httpUtils = getHttpUtils(context);
        RequestParams requestParams = new RequestParams();
        Iterator it = params.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, String> entry = (Map.Entry) it.next();
            Log.i(TAG, "key:" + entry.getKey() + ", value:" + entry.getValue());
            requestParams.addBodyParameter(entry.getKey(), entry.getValue());
        }
        httpUtils.send(HttpRequest.HttpMethod.POST, url, requestParams,
                requestCallBack);
    }
}
