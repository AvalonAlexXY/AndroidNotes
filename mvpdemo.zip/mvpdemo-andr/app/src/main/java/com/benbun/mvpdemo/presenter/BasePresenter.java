package com.benbun.mvpdemo.presenter;

import android.content.Context;

/**
 * Created by kongweixian on 16/1/15.
 */
public class BasePresenter implements Presenter {
    // root presenter为android的activity,fragment等
    private RootPresenter mRootPresenter;
    private Presenter mParentPresenter;

    public BasePresenter(RootPresenter rootPresenter) {
        mRootPresenter = rootPresenter;
        // 默认parent为root
        mParentPresenter = rootPresenter;
    }

    public Presenter getRoot() {
        return mRootPresenter;
    }

    public Context getContext() {
        return mRootPresenter.getContext();
    }

    public Presenter getParentPresenter() {
        return mParentPresenter;
    }
    public void setParentPresenter(Presenter presenter) {
        mParentPresenter = presenter;
    }
}
