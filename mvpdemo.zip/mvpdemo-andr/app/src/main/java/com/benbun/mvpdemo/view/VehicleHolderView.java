package com.benbun.mvpdemo.view;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.benbun.mvpdemo.R;
import com.benbun.mvpdemo.bean.VehicleBean;

/**
 * Created by kongweixian on 16/1/14.
 */
public class VehicleHolderView {
    public static final String TAG = "VehicleView";
    private TextView nameTv;
    private TextView snTv;
    private TextView typeTv;

    public VehicleHolderView(View parentView) {
        nameTv = (TextView) parentView.findViewById(R.id.tv_name);
        snTv = (TextView) parentView.findViewById(R.id.tv_sn);
        typeTv = (TextView) parentView.findViewById(R.id.tv_type);
    }
    public void updateData(VehicleBean vehicle) {
        // set data
        Log.i(TAG, "name" + vehicle.getVehicleName());
        nameTv.setText(vehicle.getVehicleName());
        snTv.setText(vehicle.getSn());
        typeTv.setText(vehicle.getType());
    }
}
