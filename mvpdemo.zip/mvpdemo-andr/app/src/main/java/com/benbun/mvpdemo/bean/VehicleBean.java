package com.benbun.mvpdemo.bean;

/**
 * Created by kongweixian on 16/1/15.
 */
public class VehicleBean {
    private String sn;
    private String type;
    private String vehicleName;

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }
}
