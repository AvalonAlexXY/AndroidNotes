package com.benbun.mvpdemo.webservice;

import android.content.Context;

import com.benbun.mvpdemo.utils.NetWorkUtils;
import com.lidroid.xutils.http.callback.RequestCallBack;

import java.util.HashMap;

/**
 * Created by kongweixian on 16/1/15.
 */
public class VehicleApi {
    //获取用户默认绑定车辆信息
    public static void getDefaultVehicle(Context context, String token, RequestCallBack<String> callBack) {
        HashMap<String, String> map = new HashMap<>();
        map.put("token", token);
        NetWorkUtils.getInstance().postForm("http://192.168.0.24:3003/vehicle/default", map, callBack, context);
    }
}
