package com.benbun.mvpdemo.presenter;

import android.content.Context;

/**
 * Created by kongweixian on 16/1/15.
 */
public interface Presenter {
    public Presenter getRoot();
    public Presenter getParentPresenter();
    public void setParentPresenter(Presenter presenter);
    public Context getContext();
}
